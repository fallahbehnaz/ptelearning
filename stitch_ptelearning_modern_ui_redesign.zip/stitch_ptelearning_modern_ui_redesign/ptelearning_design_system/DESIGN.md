---
name: Ptelearning Design System
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45474c'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#75777d'
  outline-variant: '#c5c6cd'
  surface-tint: '#545f73'
  primary: '#091426'
  on-primary: '#ffffff'
  primary-container: '#1e293b'
  on-primary-container: '#8590a6'
  inverse-primary: '#bcc7de'
  secondary: '#8a5100'
  on-secondary: '#ffffff'
  secondary-container: '#fe9800'
  on-secondary-container: '#643900'
  tertiary: '#111516'
  on-tertiary: '#ffffff'
  tertiary-container: '#26292b'
  on-tertiary-container: '#8d9092'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e3fb'
  primary-fixed-dim: '#bcc7de'
  on-primary-fixed: '#111c2d'
  on-primary-fixed-variant: '#3c475a'
  secondary-fixed: '#ffdcbd'
  secondary-fixed-dim: '#ffb86f'
  on-secondary-fixed: '#2c1600'
  on-secondary-fixed-variant: '#693c00'
  tertiary-fixed: '#e0e3e5'
  tertiary-fixed-dim: '#c4c7c9'
  on-tertiary-fixed: '#191c1e'
  on-tertiary-fixed-variant: '#444749'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-padding: 24px
  gutter-bento: 16px
  card-padding: 24px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

The design system is engineered for adult learners preparing for the PTE (Pearson Test of English). It emphasizes a **Corporate / Modern** aesthetic with a **Bento-style** modular layout. The brand personality is mature, professional, and motivating, avoiding the playful or overly colorful tropes of K-12 education.

Key visual principles include:
- **Modular Clarity:** Information is compartmentalized into distinct, rounded containers to reduce cognitive load.
- **Sophisticated Professionalism:** High-contrast typography and a refined, deep palette signal a high-stakes, premium learning environment.
- **Goal-Oriented Momentum:** Visual cues emphasize progress and data-driven insights rather than decorative fluff.

## Colors

The palette is anchored in high-authority tones to foster a serious study environment, now balanced by high-energy accents for better visibility of progress.

- **Primary (Deep Indigo/Navy):** `#1E293B`. Used for headlines, navigation anchors, and key "Action" surfaces. It provides the "institutional" weight required for a professional certification tool.
- **Secondary (Vibrant Amber/Orange):** `#FF9900`. Reserved specifically for progression, success states, and interactive feedback. This color represents energy, focus, and achievement.
- **Tertiary (Surface/Grey):** A range of cool neutrals (`#F8FAFC` for backgrounds) maintains a clean, clinical workspace.
- **Neutral:** Used for body text and secondary labels to ensure WCAG AA readability against the light surfaces.

## Typography

The typography system relies on **Inter** for its exceptional legibility and systematic weights. 

- **Weight Distinctions:** Use SemiBold (600) for section titles and Bold (700) for primary metrics to create an immediate hierarchy within bento cells.
- **Readability:** Body text uses a generous 1.5x line height to ensure long-form reading in study modules is comfortable.
- **Scale:** On mobile, display sizes are capped to ensure bento headers do not dominate the viewport, maintaining the modular integrity.

## Layout & Spacing

This design system utilizes a **Fluid Bento Grid** model.

- **Bento Logic:** Content is organized into a grid of 12 columns for desktop and 4 columns for mobile. Individual "cells" (cards) can span multiple columns and rows to create visual interest.
- **Margins & Gutters:** A consistent 16px gutter between bento cells ensures the layout feels breathable yet structured.
- **Study Screens:** For content-heavy exam tasks, the layout shifts to a single-column centered container (max-width 800px) to eliminate distractions and mimic actual testing environments.

## Elevation & Depth

Visual hierarchy is established through **Tonal Layers** and **Ambient Shadows** rather than stark borders.

- **The Base:** The lowest layer is the page background (`#F8FAFC`).
- **The Bento Cell:** Cards sit on the base with a subtle, extra-diffused shadow (`0px 4px 20px rgba(0, 0, 0, 0.05)`).
- **The Active Layer:** Modals and dropdowns use a higher elevation with a more pronounced shadow to indicate temporary focus.
- **Interaction:** Hovering over a bento cell should trigger a subtle upward lift (y-axis translation) and a slightly deeper shadow, providing tactile feedback to adult users.

## Shapes

The shape language is defined by significant, intentional curves that soften the "corporate" feel without becoming juvenile.

- **Bento Cards:** Use a consistent **24px corner radius** (rounded-xl) to create a modern, premium hardware-like feel.
- **Buttons & Inputs:** Use a 12px radius to maintain harmony with the larger containers while appearing more functional.
- **Progress Indicators:** Use pill-shaped (fully rounded) ends for bars and meters to signify fluidity and continuous movement.

## Components

### Bento Cards
The core unit of the design system. Every card must have a white background, 24px radius, and 24px internal padding. Content within should be bottom-aligned or centered depending on the data type (e.g., metric vs. text).

### Progression Indicators
Linear progress bars use the **Secondary Amber** against a light neutral track. For overall "Readiness Scores," use large circular gauges with SemiBold typography in the center.

### Buttons
- **Primary:** Deep Indigo background, white text, 12px radius. High-contrast.
- **Ghost:** Transparent background with an Indigo border, used for secondary study actions like "Save for Later."

### Study Controls
Minimalist playback and recording controls. Icons should be "Outlined" style with a 2pt stroke width to match the Inter typeface's weight.

### Input Fields
Soft grey backgrounds (`#F1F5F9`) with 12px rounding. Active states are indicated by a 2px Indigo border, never a glow effect, to maintain the professional tone.